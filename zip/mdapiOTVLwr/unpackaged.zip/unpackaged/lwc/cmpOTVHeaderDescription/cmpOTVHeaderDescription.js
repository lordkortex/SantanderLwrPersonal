import { LightningElement,api } from 'lwc';

export default class CmpOTVHeaderDescription extends LightningElement {


    @api title;
    @api subtitle;    
}