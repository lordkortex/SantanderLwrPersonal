({
    doInit : function(component, event, helper) {
        helper.getURLParams(component,event,helper);
	}
})