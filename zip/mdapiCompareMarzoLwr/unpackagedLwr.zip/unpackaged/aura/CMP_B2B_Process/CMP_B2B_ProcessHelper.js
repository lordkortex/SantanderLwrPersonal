({
    showToast: function (component, event, helper, title, body, noReload) {
        var errorToast = component.find('errorToast');
        if (!$A.util.isEmpty(errorToast)) {
            errorToast.openToast(false, false, title, body, 'Error', 'warning', 'warning', noReload, false);
        }
    },

    checkLastModified: function (component, helper) {
        return new Promise($A.getCallback(function (resolve, reject) {
            let steps = component.get('v.steps');
            if (steps.lastModifiedStep < steps.shownStep && steps.focusStep == steps.lastModifiedStep) {
                steps.shownStep = steps.lastModifiedStep;
            }
            component.set('v.steps', steps);
            resolve('ok');
        }),this);
    },

    nextStep: function (component, helper) {
        let steps = component.get('v.steps');
        let shownStep = steps.shownStep;
        let focusStep = steps.focusStep;
        let lastModifiedStep = steps.lastModifiedStep;
        let totalSteps = steps.totalSteps;
        if (focusStep < totalSteps) {
            if (shownStep == focusStep && shownStep == 5) {
                editPayment = true;
            }
            if (shownStep == focusStep) {
                shownStep++;
            } else if (lastModifiedStep > focusStep) {
                focusStep = lastModifiedStep;
                shownStep++;
                lastModifiedStep++;
            }
            focusStep++;
            helper.processStep(component, shownStep, focusStep, false)
            .then($A.getCallback(function (value) {
                return new Promise($A.getCallback((resolve, reject) => {
                    var stepComponent = document.getElementById('step-' + focusStep);
                    if (stepComponent != null) {
                        stepComponent.scrollIntoView({ behavior: 'smooth' });
                    } else {
                        setTimeout(function () {
                            stepComponent = document.getElementById('step-' + focusStep);
                            if (stepComponent != null) {
                                stepComponent.scrollIntoView({ behavior: 'smooth' });
                            }
                        }, 10);
                    }
                    resolve('OK');
                }));
            })).then($A.getCallback(function (value) {
                return helper.loadingEditingProcess(component, helper);
            })).catch(function (error) {
                console.log(error);
            }).finally($A.getCallback(function () {
                console.log('OK');
            }));
        }
    },

    processStep: function (component, shownStep, focusStep, editPayment) {
        return new Promise($A.getCallback(function (resolve, reject) {
            component.set('v.steps.shownStep', shownStep);
            if (!editPayment) {
                component.set('v.steps.focusStep', focusStep);
            }
            component.set('v.steps.lastModifiedStep', focusStep);
            resolve('Ok');
        }), this);
    },

    previousStep: function (component, helper) {
        let steps = component.get('v.steps');
        let shownStep = steps.shownStep;
        let focusStep = steps.focusStep;
        let totalSteps = steps.totalSteps;
        let editPayment = false;
        if (focusStep > 1) {
            if (shownStep == focusStep && shownStep == 5) {
                editPayment = true;
            }
            console.log(component.get('v.steps.focusStep'));
            if (totalSteps == focusStep) {
                shownStep -= 1;
            }
            focusStep -= 1;
            var parametros = helper.processStep(component, shownStep, focusStep, editPayment);
            parametros.then($A.getCallback(function (value) {
                if (editPayment) {
                    component.set('v.steps.focusStep', focusStep);
                }
                if (focusStep < totalSteps) {
                    var stepComponent = document.getElementById('step-' + focusStep);
                    if (stepComponent != null) {
                        stepComponent.scrollIntoView({ behavior: 'smooth' });
                    } else {
                        setTimeout(function () {
                            stepComponent = document.getElementById('step-' + focusStep);
                            if (stepComponent != null) {
                                stepComponent.scrollIntoView({ behavior: 'smooth' });
                            }
                        }, 10);
                    }
                }
            })).catch(function (error) {
                console.log(error);
            }).finally($A.getCallback(function () {
                console.log('end scrollIntoView');
            }));
        }
    },

    handleAccountsToB2BOrigin: function (component, helper, value) {
        return new Promise($A.getCallback(function (resolve, reject) {
            if (!$A.util.isEmpty(value)) {
                component.set('v.accountListOrigin', value);
                resolve('handleAccountsToB2BOrigin_OK');
            } else {
                reject({
                    'title': $A.get('$Label.c.B2B_Error_Problem_Loading'),
                    'body': $A.get('$Label.c.B2B_Problem_accounts'),
                    'noReload': false
                });
            }
        }), this);
    },

    getBeneficiaryAccounts: function (component, helper) {
        return new Promise($A.getCallback(function (resolve, reject) {
            let focusStep = component.get('v.steps.lastModifiedStep');
            if (focusStep == 1) {
                component.set('v.spinner', true);
                helper.getAccountsToB2BDestination(component, helper, component.get('v.userData'), component.get("v.dataSelectOrigin"))
                .then($A.getCallback(function (value) {
                    return helper.handleAccountsToB2BDestination(component, helper, value);
                })).then($A.getCallback(function (value) {
                    resolve('getBeneficiaryAccounts_OK');
                })).catch($A.getCallback(function (error) {
                    component.set('v.spinner', false);
                    helper.showToast(component, event, helper, error.title, error.body, error.noReload);
                    reject('getBeneficiaryAccounts_KO');
                })).finally($A.getCallback(function () {
                    component.set('v.spinner', false);
                }));
            } else {
                resolve('getBeneficiaryAccounts_OK');
            }
        }));
    },

    handleAccountsToB2BDestination: function (component, helper, value) {
        return new Promise($A.getCallback(function (resolve, reject) {
            if (!$A.util.isEmpty(value)) {
                let accountListDestination = helper.removeAccountFromList(value, component.get('v.dataSelectOrigin'));
                if (!$A.util.isEmpty(accountListDestination)) {   
                    component.set('v.accountListDestination', accountListDestination);           
                    resolve('handleAccountsToB2BDestination_OK');
                } else {
                    reject({
                        'title': $A.get('$Label.c.B2B_Error_Problem_Loading'),
                        'body': $A.get('$Label.c.B2B_Problem_accounts'),
                        'noReload': false
                    });
                }
            } else {
                reject({
                    'title': $A.get('$Label.c.B2B_Error_Problem_Loading'),
                    'body': $A.get('$Label.c.B2B_Problem_accounts'),
                    'noReload': false
                });
            }
        }), this);
    },

    removeAccountFromList: function (listToCheck, accountToDelete) {
        let newList = [];
        for (let i = 0; i < listToCheck.length; i++) {
            if (listToCheck[i].displayNumber.localeCompare(accountToDelete.displayNumber) != 0) {
                newList.push(listToCheck[i]);
            }
        }
        return newList;
    },

        getURLParams: function (component, helper) {
            return new Promise($A.getCallback(function (resolve, reject) {
                component.set('v.paymentId', '');
                component.set('v.paymentDetails', {});
                let sPageURLMain = decodeURIComponent(window.location.search.substring(1));
                let sURLVariablesMain = sPageURLMain.split('&')[0].split('=');
                if (sURLVariablesMain[0] == 'params' && !$A.util.isEmpty(sURLVariablesMain[1])) {
                    helper.decrypt(component, sURLVariablesMain[1])
                    .then($A.getCallback(function (results) {
                        let paymentId = '';
                        let paymentDetails = {};
                        let reuse = false;
                        if (!$A.util.isEmpty(results)) {
                            let sURLVariables = results.split('&');
                            for (var i = 0; i < sURLVariables.length; i++) {
                                let sParameterName = sURLVariables[i].split('=');
                                if (sParameterName[0] === 'c__paymentId') {
                                    paymentId = sParameterName[1];
                                    component.set('v.paymentId', paymentId);
                                }
                                if (sParameterName[0] === 'c__paymentDetails') {
                                    if (!$A.util.isEmpty(sParameterName[1])) {
                                        paymentDetails = JSON.parse(sParameterName[1]);
                                        component.set('v.paymentDetails', paymentDetails);
                                    }
                                }
                                if (sParameterName[0] === 'c__reuse') {
                                    if (!$A.util.isEmpty(sParameterName[1])) {
                                        reuse = JSON.parse(sParameterName[1]);
                                        component.set('v.isReuse', reuse);
                                    }
                                }
                            }
                        }
                        resolve('getURLParams_OK');
                    })).catch($A.getCallback(function (error) {
                        reject({
                            'title': $A.get('$Label.c.B2B_Error_Problem_Loading'),
                            'body': $A.get('$Label.c.B2B_Error_Check_Connection'),
                            'noReload': false
                        });
                    }));
                } else {
                    resolve('getURLParams_OK');
                }
            }));
        },
            
    initReusingProcess: function (component, helper) {
        		return new Promise($A.getCallback(function (resolve, reject) {
           		 let reuse = component.get('v.isReuse');
            let paymentDetails = component.get('v.paymentDetails');
            if (reuse && !$A.util.isEmpty(paymentDetails)) {
                component.set('v.isEditingProcess', true);
                component.set('v.isEditing', true);   
                helper.loadingEditingProcess(component, helper);
            }
            resolve('initReusingProcess');
        }));
    },
    
    initEditingProcess: function (component, helper) {
        return new Promise($A.getCallback(function (resolve, reject) {
            let paymentId = component.get('v.paymentId');
            let paymentDetails = component.get('v.paymentDetails');
            if (!$A.util.isEmpty(paymentId) && !$A.util.isEmpty(paymentDetails)) {
                component.set('v.isEditingProcess', true);
                component.set('v.isEditing', true);
                helper.loadingEditingProcess(component, helper);
            }
            resolve('initEditingProcess_OK');
        }));
    },

    loadingEditingProcess: function (component, helper) {
        return new Promise($A.getCallback((resolve, reject) => {
            let isEditingProcess = component.get('v.isEditingProcess');
            if (isEditingProcess == true) {
                let paymentDetails = component.get('v.paymentDetails');
                let focusStep = component.get('v.steps.lastModifiedStep');
                if (focusStep == 1) {
                    let dataSelectOrigin = null;
                    var originList = component.get('v.accountListOrigin');
                    if (!$A.util.isEmpty(originList)) {
                        for (let i = 0; i < originList.length && dataSelectOrigin == null; i++) {
                            if (originList[i].displayNumber == paymentDetails.sourceAccount.trim()) {
                                dataSelectOrigin = originList[i];
                            }
                        }
                    }
                    if (!$A.util.isEmpty(dataSelectOrigin)) {
                        component.set('v.dataSelectOrigin', dataSelectOrigin);
                        let selectOrigin = component.find('selectOrigin');
                        selectOrigin.checkContinue(1);
                    }
                } else if (focusStep == 2) {
                    let dataSelectDestination = null;
                    var destinationList = component.get('v.accountListDestination');
                    if (!$A.util.isEmpty(destinationList)) {
                        for (let i = 0; i < destinationList.length && dataSelectDestination == null; i++) {
                            if (destinationList[i].displayNumber == paymentDetails.beneficiaryAccount.trim()) {
                                dataSelectDestination = destinationList[i];
                            }
                        }
                    }
                    if (!$A.util.isEmpty(dataSelectDestination)) {
                        component.set('v.dataSelectDestination', dataSelectDestination);
                        let selectDestination = component.find('selectDestination');
                        selectDestination.checkContinue(2);
                    }
                } else if (focusStep == 3) {
                    let dataSelectAmount = {};
                    let amountEntered = null;
                    let amountEnteredFrom = '';
                    if (!$A.util.isEmpty(paymentDetails.operationAmount) && !$A.util.isEmpty(paymentDetails.operationAmount.amount)) {
                        if (!$A.util.isEmpty(paymentDetails.operationNominalFxDetails) && !$A.util.isEmpty(paymentDetails.operationNominalFxDetails.customerExchangeRate)) {
                            dataSelectAmount.amountReceive = paymentDetails.operationAmount.amount;
                            amountEntered = paymentDetails.operationAmount.amount;
                            amountEnteredFrom = 'recipient';
                        } else {
                            dataSelectAmount.amountSend = paymentDetails.operationAmount.amount;
                            amountEntered = paymentDetails.operationAmount.amount;
                            amountEnteredFrom = 'source';
                        }
                    } else if (!$A.util.isEmpty(paymentDetails.counterValueOperationAmount) && !$A.util.isEmpty(paymentDetails.counterValueOperationAmount.amount)) {
                        dataSelectAmount.amountSend = paymentDetails.counterValueOperationAmount.amount;
                        amountEntered = paymentDetails.counterValueOperationAmount.amount;
                        amountEnteredFrom = 'source';
                    }
                    component.set('v.dataSelectAmount', dataSelectAmount);
                    let selectAmount = component.find('selectAmount');
                    selectAmount.editingProcess(amountEntered, amountEnteredFrom);
                    component.set('v.isEditingProcess', false);
                    component.set('v.paymentDetails', {});
                } else {
                    component.set('v.isEditingProcess', false);
                    component.set('v.paymentDetails', {});
                }
            }
            resolve('initEditingProcess_OK');
        }));
    },

    /*
    Author:         R. Alexander Cervino
    Company:        Deloitte
    Description:    Method to decrypt data
    History:
    <Date>          <Author>                    <Description>
    19/11/2019      R. Alexander Cervino        Initial version
    */
    decrypt: function (component, data) {
        return new Promise(function (resolve, reject) {
            var action = component.get('c.decryptData');
            action.setParams({
                'str': data
            });
            action.setCallback(this, function (response) {
                var result = 'null';
                var state = response.getState();
                if (state === 'ERROR') {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log('Error message: ' + errors[0].message);
                            reject(response.getError()[0]);
                        }
                    } else {
                        console.log('Unknown error');
                    }
                } else if (state === 'SUCCESS') {
                    result = response.getReturnValue();
                }
                resolve(result);
            });
            $A.enqueueAction(action);
        });
    },

    getAccountData: function (component, helper) {
        return new Promise($A.getCallback(function (resolve, reject) {
            var action = component.get('c.getAccountData');
            action.setCallback(this, function (actionResult) {
                if (actionResult.getState() == 'SUCCESS') {
                    var accountData = {};
                    var stateRV = actionResult.getReturnValue();
                    if (stateRV.success) {
                        if (!$A.util.isEmpty(stateRV.value.cib)) {
                            accountData.cib = stateRV.value.cib;
                        } else { // FLOWERPOWER_PARCHE_MINIGO
                            accountData.cib = false; // Añadir un error
                        }
                        if (!$A.util.isEmpty(stateRV.value.documentType)) {
                            accountData.documentType = stateRV.value.documentType;
                        } else { // FLOWERPOWER_PARCHE_MINIGO
                            accountData.documentType = 'tax_id'; // Añadir un error
                        }
                        if (!$A.util.isEmpty(stateRV.value.documentNumber)) {
                            accountData.documentNumber = stateRV.value.documentNumber;
                        } else { // FLOWERPOWER_PARCHE_MINIGO
                            accountData.documentNumber = 'B86561412'; // Añadir un error
                        }
                        if (!$A.util.isEmpty(stateRV.value.companyId)) {
                            accountData.companyId = stateRV.value.companyId;
                        } else { // FLOWERPOWER_PARCHE_MINIGO
                            accountData.companyId = '2119'; // Añadir un error
                        }
                    }
                    component.set('v.accountData', accountData);
                    resolve('getAccountData_OK');
                } else if (actionResult.getState() == 'ERROR') {
                    var errors = response.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log('Error message: ' + errors[0].message);
                        }
                    }
                    reject({
                        'title': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                        'body': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                        'noReload': true
                    });
                }
            });
            $A.enqueueAction(action);
        }), this);
    },

    getUserData: function (component, helper) {
        return new Promise($A.getCallback(function (resolve, reject) {
            var action = component.get('c.getUserData');
            action.setCallback(this, function (actionResult) {
                if (actionResult.getState() == 'SUCCESS') {
                    var stateRV = actionResult.getReturnValue();
                    if (stateRV.success) {
                        if (!$A.util.isEmpty(stateRV.value)) {
                            if (!$A.util.isEmpty(stateRV.value.userData)) {
                                component.set('v.userData', stateRV.value.userData);
                                resolve('getUserData_OK');
                            } else {
                                reject({
                                    'title': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                                    'body': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                                    'noReload': true
                                });
                            }
                        } else {
                            reject({
                                'title': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                                'body': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                                'noReload': true
                            });
                        }
                    } else {
                        reject({
                            'title': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                            'body': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                            'noReload': true
                        });
                    }
                } else if (actionResult.getState() == 'ERROR') {
                    var errors = actionResult.getError();
                    if (errors) {
                        if (errors[0] && errors[0].message) {
                            console.log('Error message: ' + errors[0].message);
                        }
                    }
                    reject({
                        'title': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                        'body': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                        'noReload': true
                    });
                } else {
                    reject({
                        'title': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                        'body': $A.get('$Label.c.ERROR_NOT_RETRIEVED'),
                        'noReload': true
                    });
                }
            });
            $A.enqueueAction(action);
        }), this);
    }

  
})