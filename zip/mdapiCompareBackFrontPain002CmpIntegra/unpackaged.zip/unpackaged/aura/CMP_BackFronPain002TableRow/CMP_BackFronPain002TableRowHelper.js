({
    delete : function(component, event, helper) {

    }
})